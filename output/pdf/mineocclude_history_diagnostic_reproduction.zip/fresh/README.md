# MineOcclude fresh-cohort reproduction

This snapshot contains 75 newly captured identities: 25 original-setting,
25 changed-geometry, and 25 higher-speed identities. Every identity has paired
air and stone captures and 19 fixed target times. All predictions are measured,
not hypothetical. Engineering pilots are excluded.

## CPU-only verification

Use Python 3.10--3.12 in a clean environment:

```
python -m pip install -r requirements-cpu.txt
python test_statistics.py
python reproduce.py
```

The last command verifies every listed input hash and exactly rebuilds the
supplied statistics from 19,950 primary and 5,700 secondary transfer prediction
cells. It requires neither a GPU nor Minecraft, model weights, or activations.
Primary fits are identity-grouped and fitted separately within each setting.
Transfer fits use only the 25 fresh original-setting source identities; all
destination labels are scoring-only. These analyses must not be pooled.

The manifest contains targets, raw state history, target indices, and exact
outer/inner folds. Per-prediction files record alpha selection and source hashes.
Intervals use 10,000 paired identity resamples (seed 20260911), conditional on
fitted probes; they are not simultaneous or refitting intervals.

## Full capture and inference

The companion mineocclude_fresh_75_captures.zip contains the full 150 recordings,
27,000 actual Minecraft frames, state/action/tick logs, and per-file hashes.
It does not include Minecraft binaries or model weights. The accompanying
execution source and runtime receipts document full extraction and fitting.
The CPU-only command above reconstructs statistics, not neural inference.

The original graded-evidence RGB follow-up has a separate preserved reproduction
snapshot. This package is a fresh extension, not a replacement of its identities.
Anonymous public distribution has not been verified by creating these local files.
