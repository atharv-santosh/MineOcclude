"""Fail-closed C/D/E consumer requirements owned by Person B.

These validators define what B needs to perform analysis. They do not claim
that another role has produced or signed a matching artifact yet.
"""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
from typing import Any

from mineocclude.analysis.coordinates import (
    CoordinateContractError,
    validate_coordinate_frame,
)
from mineocclude.analysis.manifests import (
    AnalysisArtifactError,
    is_hex_digest,
    sha256_value,
)
from mineocclude.contracts.baseline_family_inputs import (
    BASELINE_FAMILY_CONTRACTS_V0_2,
    BASELINE_INPUT_SCHEMA_VERSION_V0_2,
    FROZEN_DIRECT_INPUTS,
    FROZEN_PILOT_IDS,
    PERSON_B_PREDICTION_RESERVATION,
    is_valid_artifact_reference,
)
from mineocclude.contracts.identity import (
    FRAME_KEY,
    SCHEMA_VERSION,
    IdentityValidationError,
    get_key,
    validate_identity,
)

STATE_INPUT_SCHEMA_VERSION = "person-b-state-input-v0.1"
BASELINE_INPUT_SCHEMA_VERSION = "person-b-baseline-input-v0.1"
MEASUREMENT_INPUT_SCHEMA_VERSION = "person-b-u4-measurement-input-v0.1"

BASELINE_LEGAL_INFORMATION_FIELDS = frozenset(
    {
        "uses_hidden_truth",
        "uses_future_information",
        "uses_scripted_q",
    }
)
BASELINE_FAMILY_CONTRACTS = {
    "last_seen": {
        "target_names": frozenset({"mu_oracle_blocks"}),
        "feature_access": frozenset(
            {
                "last_visible_position_blocks",
                "tau",
                "visibility",
            }
        ),
        "legal_information": {
            "uses_hidden_truth": False,
            "uses_future_information": False,
            "uses_scripted_q": False,
        },
    }
}


class AnalysisInputRejectionCode(str, Enum):
    MISSING_REQUIRED_FIELD = "missing_required_field"
    INVALID_SCHEMA_VERSION = "invalid_schema_version"
    INVALID_PRODUCER_ROLE = "invalid_producer_role"
    INVALID_HASH = "invalid_hash"
    INVALID_COORDINATE_FRAME = "invalid_coordinate_frame"
    INVALID_IDENTITY = "invalid_identity"
    DUPLICATE_IDENTITY = "duplicate_identity"
    MANIFEST_MISMATCH = "manifest_mismatch"
    INVALID_VALUE = "invalid_value"
    INVALID_LIFECYCLE = "invalid_lifecycle"
    FOLD_MISMATCH = "fold_mismatch"
    NON_OOF_PREDICTION = "non_oof_prediction"
    OUTCOME_CONFLATION = "outcome_conflation"
    UNSUPPORTED_BASELINE_FAMILY = "unsupported_baseline_family"
    LEGAL_INFORMATION_VIOLATION = "legal_information_violation"
    MIXED_EPISODE_ID = "mixed_episode_id"
    NONCONSECUTIVE_SERVER_TICK = "nonconsecutive_server_tick"
    TIMEBASE_MISMATCH = "timebase_mismatch"
    INVALID_ROLLOUT_REGISTRY_BUNDLE = "invalid_rollout_registry_bundle"
    ROLLOUT_LOOKUP_MISMATCH = "rollout_lookup_mismatch"


@dataclass(frozen=True)
class AnalysisInputRejection:
    code: AnalysisInputRejectionCode
    message: str
    row_index: int | None = None


@dataclass(frozen=True)
class AnalysisInputValidationResult:
    accepted: bool
    rejections: tuple[AnalysisInputRejection, ...]


def _reject(
    rejections: list[AnalysisInputRejection],
    code: AnalysisInputRejectionCode,
    message: str,
    row_index: int | None = None,
) -> None:
    rejections.append(AnalysisInputRejection(code, message, row_index))


def _finite(value: Any) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(float(value))
    )


def _require_envelope(
    document: Any,
    *,
    version_field: str,
    version: str,
    producer_role: str,
    required: tuple[str, ...],
) -> tuple[list[AnalysisInputRejection], list[Any] | None]:
    rejections: list[AnalysisInputRejection] = []
    if not isinstance(document, Mapping):
        _reject(
            rejections,
            AnalysisInputRejectionCode.MISSING_REQUIRED_FIELD,
            "Input document must be a mapping.",
        )
        return rejections, None
    missing = [field for field in required if field not in document]
    if missing:
        _reject(
            rejections,
            AnalysisInputRejectionCode.MISSING_REQUIRED_FIELD,
            "Input document is missing: " + ", ".join(missing),
        )
        return rejections, None
    if (
        document.get("schema_version") != SCHEMA_VERSION
        or document.get(version_field) != version
    ):
        _reject(
            rejections,
            AnalysisInputRejectionCode.INVALID_SCHEMA_VERSION,
            "Input schema version mismatch.",
        )
    if document.get("producer_role") != producer_role:
        _reject(
            rejections,
            AnalysisInputRejectionCode.INVALID_PRODUCER_ROLE,
            f"Expected producer_role={producer_role!r}.",
        )
    rows = document.get("rows")
    if not isinstance(rows, list) or not rows:
        _reject(
            rejections,
            AnalysisInputRejectionCode.MISSING_REQUIRED_FIELD,
            "Input document requires a non-empty rows list.",
        )
        return rejections, None
    return rejections, rows


def validate_state_input(document: Any) -> AnalysisInputValidationResult:
    """Validate the signed wall-parallel state table required from C."""

    required = (
        "schema_version",
        "state_input_schema_version",
        "producer_role",
        "join_key",
        "accepted_manifest_hash",
        "coordinate_frame",
        "rows",
    )
    rejections, rows = _require_envelope(
        document,
        version_field="state_input_schema_version",
        version=STATE_INPUT_SCHEMA_VERSION,
        producer_role="person_c",
        required=required,
    )
    if rows is None or not isinstance(document, Mapping):
        return AnalysisInputValidationResult(False, tuple(rejections))
    if document.get("join_key") != list(FRAME_KEY):
        _reject(
            rejections,
            AnalysisInputRejectionCode.INVALID_VALUE,
            "State input join_key must use the universal frame key.",
        )
    manifest_hash = document.get("accepted_manifest_hash")
    if not is_hex_digest(manifest_hash, 64):
        _reject(
            rejections,
            AnalysisInputRejectionCode.INVALID_HASH,
            "accepted_manifest_hash must be SHA-256.",
        )
    # Import locally to keep the public contracts package independent from the
    # oracle package's builder imports during module initialization.
    from mineocclude.oracle.schema import (
        OracleRejectionCode,
        OracleValidationError,
        validate_trajectory_timebase_rows,
    )

    try:
        validate_coordinate_frame(document.get("coordinate_frame"))
    except CoordinateContractError as error:
        _reject(
            rejections,
            AnalysisInputRejectionCode.INVALID_COORDINATE_FRAME,
            str(error),
        )
    seen: set[tuple[Any, ...]] = set()
    identity_valid_rows: list[Mapping[str, Any]] = []
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_IDENTITY,
                "State row must be a mapping.",
                index,
            )
            continue
        try:
            validate_identity(row)
            key = get_key(row)
        except IdentityValidationError as error:
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_IDENTITY,
                str(error),
                index,
            )
            continue
        identity_valid_rows.append(row)
        if key in seen:
            _reject(
                rejections,
                AnalysisInputRejectionCode.DUPLICATE_IDENTITY,
                f"Duplicate state row {key}.",
                index,
            )
        seen.add(key)
        if row.get("status") != "accepted":
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_LIFECYCLE,
                "Only accepted state rows may enter target construction.",
                index,
            )
        if row.get("accepted_manifest_hash") != manifest_hash:
            _reject(
                rejections,
                AnalysisInputRejectionCode.MANIFEST_MISMATCH,
                "State row accepted-manifest hash differs from the envelope.",
                index,
            )
        for field in ("x_true_blocks", "observed_position_blocks"):
            if field not in row:
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.MISSING_REQUIRED_FIELD,
                    f"State row is missing {field}.",
                    index,
                )
        observed = row.get("observed_position_blocks")
        if row.get("visibility") == "visible":
            if not _finite(observed):
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.INVALID_VALUE,
                    "Visible state rows require a finite observed position.",
                    index,
                )
        elif observed is not None:
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_VALUE,
                "Occluded state rows cannot expose observed position.",
                index,
            )
        if not _finite(row.get("x_true_blocks")):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_VALUE,
                "x_true_blocks must be finite scoring-only truth.",
                index,
            )
    try:
        validate_trajectory_timebase_rows(identity_valid_rows)
    except OracleValidationError as error:
        code_map = {
            OracleRejectionCode.MIXED_EPISODE_ID: (
                AnalysisInputRejectionCode.MIXED_EPISODE_ID
            ),
            OracleRejectionCode.NONCONSECUTIVE_SERVER_TICK: (
                AnalysisInputRejectionCode.NONCONSECUTIVE_SERVER_TICK
            ),
            OracleRejectionCode.TIMEBASE_MISMATCH: (
                AnalysisInputRejectionCode.TIMEBASE_MISMATCH
            ),
        }
        _reject(
            rejections,
            code_map.get(error.code, AnalysisInputRejectionCode.INVALID_VALUE),
            str(error),
        )
    return AnalysisInputValidationResult(not rejections, tuple(rejections))


def _validate_baseline_input_v0_1(
    document: Any,
    *,
    expected_fold_by_frame: Mapping[tuple[str, int], int] | None = None,
) -> AnalysisInputValidationResult:
    """Validate D-to-B baseline predictions as OOF rows with locked folds."""

    required = (
        "schema_version",
        "baseline_input_schema_version",
        "producer_role",
        "baseline_id",
        "baseline_family",
        "target_name",
        "feature_access",
        "legal_information",
        "config_hash",
        "input_manifest_hash",
        "fold_manifest_hash",
        "fit_manifest_hash",
        "rows",
    )
    rejections, rows = _require_envelope(
        document,
        version_field="baseline_input_schema_version",
        version=BASELINE_INPUT_SCHEMA_VERSION,
        producer_role="person_d",
        required=required,
    )
    if rows is None or not isinstance(document, Mapping):
        return AnalysisInputValidationResult(False, tuple(rejections))
    for field in (
        "config_hash",
        "input_manifest_hash",
        "fold_manifest_hash",
        "fit_manifest_hash",
    ):
        if not is_hex_digest(document.get(field), 64):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_HASH,
                f"{field} must be SHA-256.",
            )
    for field in ("baseline_id", "baseline_family", "target_name"):
        if not isinstance(document.get(field), str) or not document[field].strip():
            _reject(
                rejections,
                AnalysisInputRejectionCode.MISSING_REQUIRED_FIELD,
                f"{field} must be non-empty.",
            )
    baseline_family = document.get("baseline_family")
    if (
        isinstance(baseline_family, str)
        and baseline_family.strip()
        and baseline_family not in BASELINE_FAMILY_CONTRACTS
    ):
        _reject(
            rejections,
            AnalysisInputRejectionCode.UNSUPPORTED_BASELINE_FAMILY,
            f"Unsupported baseline_family={baseline_family!r}.",
        )
    family_contract = (
        BASELINE_FAMILY_CONTRACTS.get(baseline_family)
        if isinstance(baseline_family, str)
        else None
    )
    target_name = document.get("target_name")
    if (
        family_contract is not None
        and isinstance(target_name, str)
        and target_name.strip()
        and target_name not in family_contract["target_names"]
    ):
        _reject(
            rejections,
            AnalysisInputRejectionCode.LEGAL_INFORMATION_VIOLATION,
            f"target_name={target_name!r} is not allowed for {baseline_family!r}.",
        )

    feature_access = document.get("feature_access")
    if (
        not isinstance(feature_access, list)
        or not feature_access
        or any(
            not isinstance(field, str) or not field.strip()
            for field in feature_access
        )
        or len(feature_access) != len(set(feature_access))
    ):
        _reject(
            rejections,
            AnalysisInputRejectionCode.INVALID_VALUE,
            "feature_access must be a non-empty list of unique field names.",
        )
    elif family_contract is not None:
        declared_features = frozenset(feature_access)
        allowed_features = family_contract["feature_access"]
        if declared_features != allowed_features:
            unexpected = sorted(declared_features - allowed_features)
            missing = sorted(allowed_features - declared_features)
            _reject(
                rejections,
                AnalysisInputRejectionCode.LEGAL_INFORMATION_VIOLATION,
                "feature_access does not exactly match the family allowlist. "
                f"Unexpected: {unexpected}. Missing: {missing}.",
            )

    legal_information = document.get("legal_information")
    if (
        not isinstance(legal_information, Mapping)
        or set(legal_information) != BASELINE_LEGAL_INFORMATION_FIELDS
        or any(
            not isinstance(legal_information.get(field), bool)
            for field in BASELINE_LEGAL_INFORMATION_FIELDS
        )
    ):
        _reject(
            rejections,
            AnalysisInputRejectionCode.INVALID_VALUE,
            "legal_information must explicitly declare all access flags as booleans.",
        )
    elif (
        family_contract is not None
        and dict(legal_information) != family_contract["legal_information"]
    ):
        _reject(
            rejections,
            AnalysisInputRejectionCode.LEGAL_INFORMATION_VIOLATION,
            "legal_information does not match the baseline-family contract.",
        )
    seen: set[tuple[str, int]] = set()
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_VALUE,
                "Baseline row must be a mapping.",
                index,
            )
            continue
        required_row = (
            "trajectory_id",
            "model_frame_idx",
            "fold_idx",
            "prediction",
            "prediction_scope",
            "fit_id",
        )
        missing = [field for field in required_row if field not in row]
        if missing:
            _reject(
                rejections,
                AnalysisInputRejectionCode.MISSING_REQUIRED_FIELD,
                "Baseline row is missing: " + ", ".join(missing),
                index,
            )
            continue
        key = (row["trajectory_id"], row["model_frame_idx"])
        if (
            not isinstance(row["trajectory_id"], str)
            or not row["trajectory_id"]
            or not isinstance(row["model_frame_idx"], int)
            or isinstance(row["model_frame_idx"], bool)
            or row["model_frame_idx"] < 0
            or not isinstance(row["fold_idx"], int)
            or isinstance(row["fold_idx"], bool)
            or row["fold_idx"] < 0
            or not isinstance(row["fit_id"], str)
            or not row["fit_id"]
        ):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_IDENTITY,
                "Baseline frame/fold/fit identity is invalid.",
                index,
            )
            continue
        if key in seen:
            _reject(
                rejections,
                AnalysisInputRejectionCode.DUPLICATE_IDENTITY,
                f"Duplicate baseline prediction {key}.",
                index,
            )
        seen.add(key)
        if not _finite(row["prediction"]):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_VALUE,
                "Baseline prediction must be finite.",
                index,
            )
        if row["prediction_scope"] != "out_of_fold":
            _reject(
                rejections,
                AnalysisInputRejectionCode.NON_OOF_PREDICTION,
                "Scientific baseline rows must be out-of-fold.",
                index,
            )
        if expected_fold_by_frame is not None:
            expected = expected_fold_by_frame.get(key)
            if expected is None or row["fold_idx"] != expected:
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.FOLD_MISMATCH,
                    "Baseline fold does not match B's frozen fold manifest.",
                    index,
                )
    if expected_fold_by_frame is not None and seen != set(expected_fold_by_frame):
        _reject(
            rejections,
            AnalysisInputRejectionCode.MANIFEST_MISMATCH,
            "Baseline rows do not exactly cover B's accepted frame keys.",
        )
    return AnalysisInputValidationResult(not rejections, tuple(rejections))


def _validate_baseline_input_v0_2(
    document: Any,
    *,
    expected_fold_by_frame: Mapping[tuple[str, int], int] | None = None,
) -> AnalysisInputValidationResult:
    """Validate an eight-family D-to-B prediction under the v0.2 contract."""

    required = (
        "schema_version",
        "baseline_input_schema_version",
        "producer_role",
        "baseline_id",
        "baseline_family",
        "target_name",
        "feature_access",
        "legal_information",
        "config_hash",
        "input_manifest_hash",
        "fold_manifest_hash",
        "fit_manifest_hash",
        "direct_inputs",
        "accepted_pilot_ids",
        "person_b_prediction_reservation",
        "random_split_used",
        "u4_output_inspected",
        "rows",
    )
    rejections, rows = _require_envelope(
        document,
        version_field="baseline_input_schema_version",
        version=BASELINE_INPUT_SCHEMA_VERSION_V0_2,
        producer_role="person_d",
        required=required,
    )
    if rows is None or not isinstance(document, Mapping):
        return AnalysisInputValidationResult(False, tuple(rejections))

    family = document.get("baseline_family")
    contract = (
        BASELINE_FAMILY_CONTRACTS_V0_2.get(family)
        if isinstance(family, str)
        else None
    )
    if contract is None:
        _reject(
            rejections,
            AnalysisInputRejectionCode.UNSUPPORTED_BASELINE_FAMILY,
            f"Unsupported v0.2 baseline_family={family!r}.",
        )
    target_name = document.get("target_name")
    if contract is not None and target_name not in contract["target_names"]:
        _reject(
            rejections,
            AnalysisInputRejectionCode.LEGAL_INFORMATION_VIOLATION,
            f"target_name={target_name!r} is not allowed for {family!r}.",
        )
    feature_access = document.get("feature_access")
    valid_feature_list = (
        isinstance(feature_access, list)
        and bool(feature_access)
        and all(isinstance(item, str) and item for item in feature_access)
    )
    if not valid_feature_list or contract is None:
        if not isinstance(feature_access, list):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_VALUE,
                "feature_access must be a list.",
            )
        elif not valid_feature_list:
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_VALUE,
                "feature_access must contain non-empty field names.",
            )
    elif frozenset(feature_access) != contract["feature_access"] or (
        len(feature_access) != len(set(feature_access))
    ):
        _reject(
            rejections,
            AnalysisInputRejectionCode.LEGAL_INFORMATION_VIOLATION,
            "feature_access does not exactly match the v0.2 family contract.",
        )
    legal_information = document.get("legal_information")
    if contract is not None and legal_information != contract["legal_information"]:
        _reject(
            rejections,
            AnalysisInputRejectionCode.LEGAL_INFORMATION_VIOLATION,
            "legal_information does not exactly match the v0.2 family contract.",
        )

    for field in (
        "config_hash",
        "input_manifest_hash",
        "fold_manifest_hash",
        "fit_manifest_hash",
    ):
        if not is_hex_digest(document.get(field), 64):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_HASH,
                f"{field} must be SHA-256.",
            )
    if document.get("config_hash") != FROZEN_DIRECT_INPUTS["analysis_config"][
        "sha256"
    ]:
        _reject(
            rejections,
            AnalysisInputRejectionCode.MANIFEST_MISMATCH,
            "config_hash does not match the frozen analysis config bytes.",
        )
    if document.get("fold_manifest_hash") != FROZEN_DIRECT_INPUTS[
        "fold_manifest"
    ]["sha256"]:
        _reject(
            rejections,
            AnalysisInputRejectionCode.MANIFEST_MISMATCH,
            "fold_manifest_hash does not match the frozen production manifest.",
        )

    direct_inputs = document.get("direct_inputs")
    if not isinstance(direct_inputs, Mapping):
        _reject(
            rejections,
            AnalysisInputRejectionCode.MISSING_REQUIRED_FIELD,
            "direct_inputs must be a mapping.",
        )
    else:
        required_direct_input_types = {
            *FROZEN_DIRECT_INPUTS,
        }
        if family == "raw_pixel":
            required_direct_input_types.add("preprocessed_frame_manifest")
        if set(direct_inputs) != required_direct_input_types:
            _reject(
                rejections,
                AnalysisInputRejectionCode.MANIFEST_MISMATCH,
                "direct_inputs contains a missing or unauthorized artifact type.",
            )
        for artifact_type, expected in FROZEN_DIRECT_INPUTS.items():
            if direct_inputs.get(artifact_type) != expected:
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.MANIFEST_MISMATCH,
                    f"{artifact_type} does not match its frozen byte identity.",
                )
        if family == "raw_pixel" and not is_valid_artifact_reference(
            direct_inputs.get("preprocessed_frame_manifest")
        ):
            _reject(
                rejections,
                AnalysisInputRejectionCode.MISSING_REQUIRED_FIELD,
                "raw_pixel requires an exact preprocessed_frame_manifest.",
            )
        if any(key.startswith("person_b_prediction") for key in direct_inputs):
            _reject(
                rejections,
                AnalysisInputRejectionCode.LEGAL_INFORMATION_VIOLATION,
                "Person B predictions are reserved for later comparison.",
            )
    accepted_pilot_ids = document.get("accepted_pilot_ids")
    if not isinstance(accepted_pilot_ids, list) or (
        tuple(accepted_pilot_ids) != FROZEN_PILOT_IDS
    ):
        _reject(
            rejections,
            AnalysisInputRejectionCode.MANIFEST_MISMATCH,
            "accepted_pilot_ids must equal the frozen ordered ten-pilot set.",
        )
    if document.get("person_b_prediction_reservation") != (
        PERSON_B_PREDICTION_RESERVATION
    ):
        _reject(
            rejections,
            AnalysisInputRejectionCode.MANIFEST_MISMATCH,
            "Person B prediction reservation is missing or altered.",
        )
    if document.get("random_split_used") is not False:
        _reject(
            rejections,
            AnalysisInputRejectionCode.FOLD_MISMATCH,
            "Random splits are forbidden.",
        )
    if document.get("u4_output_inspected") is not False:
        _reject(
            rejections,
            AnalysisInputRejectionCode.LEGAL_INFORMATION_VIOLATION,
            "U4 output access is forbidden.",
        )

    seen: set[tuple[str, int]] = set()
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_VALUE,
                "Baseline row must be a mapping.",
                index,
            )
            continue
        required_row = (
            "trajectory_id",
            "model_frame_idx",
            "fold_idx",
            "prediction",
            "prediction_scope",
            "fit_id",
        )
        missing = [field for field in required_row if field not in row]
        if missing:
            _reject(
                rejections,
                AnalysisInputRejectionCode.MISSING_REQUIRED_FIELD,
                "Baseline row is missing: " + ", ".join(missing),
                index,
            )
            continue
        key = (row["trajectory_id"], row["model_frame_idx"])
        if (
            row["trajectory_id"] not in FROZEN_PILOT_IDS
            or not isinstance(row["model_frame_idx"], int)
            or isinstance(row["model_frame_idx"], bool)
            or row["model_frame_idx"] < 0
            or not isinstance(row["fold_idx"], int)
            or isinstance(row["fold_idx"], bool)
            or row["fold_idx"] < 0
            or not isinstance(row["fit_id"], str)
            or not row["fit_id"]
        ):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_IDENTITY,
                "Baseline frame/fold/fit identity is invalid.",
                index,
            )
            continue
        if key in seen:
            _reject(
                rejections,
                AnalysisInputRejectionCode.DUPLICATE_IDENTITY,
                f"Duplicate baseline prediction {key}.",
                index,
            )
        seen.add(key)
        if not _finite(row["prediction"]):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_VALUE,
                "Baseline prediction must be finite.",
                index,
            )
        if row["prediction_scope"] != "out_of_fold":
            _reject(
                rejections,
                AnalysisInputRejectionCode.NON_OOF_PREDICTION,
                "Scientific baseline rows must be out-of-fold.",
                index,
            )
        if expected_fold_by_frame is not None:
            expected = expected_fold_by_frame.get(key)
            if expected is None or row["fold_idx"] != expected:
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.FOLD_MISMATCH,
                    "Baseline fold does not match B's frozen fold manifest.",
                    index,
                )
    if expected_fold_by_frame is not None and seen != set(expected_fold_by_frame):
        _reject(
            rejections,
            AnalysisInputRejectionCode.MANIFEST_MISMATCH,
            "Baseline rows do not exactly cover B's accepted frame keys.",
        )
    return AnalysisInputValidationResult(not rejections, tuple(rejections))


def validate_baseline_input(
    document: Any,
    *,
    expected_fold_by_frame: Mapping[tuple[str, int], int] | None = None,
) -> AnalysisInputValidationResult:
    """Dispatch D-to-B prediction validation by explicit contract version."""

    if isinstance(document, Mapping) and document.get(
        "baseline_input_schema_version"
    ) == BASELINE_INPUT_SCHEMA_VERSION_V0_2:
        return _validate_baseline_input_v0_2(
            document,
            expected_fold_by_frame=expected_fold_by_frame,
        )
    return _validate_baseline_input_v0_1(
        document,
        expected_fold_by_frame=expected_fold_by_frame,
    )


def validate_measurement_input(
    document: Any,
    *,
    rollout_manifest: Any = None,
    registry: Any = None,
    expected_rollouts_by_id: Mapping[str, Mapping[str, Any]] | None = None,
) -> AnalysisInputValidationResult:
    """Validate E measurements against an actual validated A handoff bundle.

    ``expected_rollouts_by_id`` is accepted only as an untrusted compatibility
    assertion. Scientific expectations are always derived internally from the
    validated rollout manifest and registry.
    """

    required = (
        "schema_version",
        "measurement_input_schema_version",
        "producer_role",
        "accepted_rollout_manifest_hash",
        "accepted_registry_hash",
        "measurement_config_hash",
        "rows",
    )
    rejections, rows = _require_envelope(
        document,
        version_field="measurement_input_schema_version",
        version=MEASUREMENT_INPUT_SCHEMA_VERSION,
        producer_role="person_e",
        required=required,
    )
    if rows is None or not isinstance(document, Mapping):
        return AnalysisInputValidationResult(False, tuple(rejections))
    claimed_rollouts_by_id = expected_rollouts_by_id
    if claimed_rollouts_by_id is not None and not isinstance(
        claimed_rollouts_by_id, Mapping
    ):
        _reject(
            rejections,
            AnalysisInputRejectionCode.INVALID_VALUE,
            "expected_rollouts_by_id must be a mapping when supplied.",
        )
        claimed_rollouts_by_id = None
    for field in (
        "accepted_rollout_manifest_hash",
        "accepted_registry_hash",
        "measurement_config_hash",
    ):
        if not is_hex_digest(document.get(field), 64):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_HASH,
                f"{field} must be SHA-256.",
            )

    derived_rollouts_by_id: dict[str, dict[str, Any]] = {}
    bundle_valid = False
    try:
        from mineocclude.contracts.rollout_registry import (
            validate_rollout_registry_bundle,
        )

        bundle_result = validate_rollout_registry_bundle(
            rollout_manifest,
            registry,
        )
    except (AttributeError, KeyError, TypeError, ValueError) as error:
        _reject(
            rejections,
            AnalysisInputRejectionCode.INVALID_ROLLOUT_REGISTRY_BUNDLE,
            f"A rollout/registry validation failed safely: {error}",
        )
        bundle_result = None

    if bundle_result is None or not bundle_result.accepted:
        if bundle_result is not None:
            rejection_codes = sorted(
                {item.code.value for item in bundle_result.rejections}
            )
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_ROLLOUT_REGISTRY_BUNDLE,
                "A rollout/registry bundle is invalid: "
                + ", ".join(rejection_codes),
            )
    else:
        try:
            rollout_manifest_hash = sha256_value(rollout_manifest)
            registry_hash = sha256_value(registry)
        except AnalysisArtifactError as error:
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_ROLLOUT_REGISTRY_BUNDLE,
                str(error),
            )
        else:
            bundle_valid = True
            if (
                document.get("accepted_rollout_manifest_hash")
                != rollout_manifest_hash
            ):
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.MANIFEST_MISMATCH,
                    "Measurement envelope names a different rollout manifest.",
                )
            if document.get("accepted_registry_hash") != registry_hash:
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.MANIFEST_MISMATCH,
                    "Measurement envelope names a different rollout registry.",
                )

            run_by_id = {run["run_id"]: run for run in registry["runs"]}
            derived_rollouts_by_id = {
                rollout["rollout_id"]: {
                    "event_id": rollout["event_id"],
                    "direction_version": rollout["direction_version"],
                    "control_type": rollout["control_type"],
                    "alpha_applied": rollout["alpha_applied"],
                    "outcome": rollout["outcome"],
                    "measurable": rollout["measurable"],
                    "status": rollout["status"],
                    "run_id": rollout["run_id"],
                    "execution_status": run_by_id[rollout["run_id"]][
                        "execution_status"
                    ],
                }
                for rollout in rollout_manifest["rollout_rows"]
            }

    if (
        bundle_valid
        and claimed_rollouts_by_id is not None
        and claimed_rollouts_by_id != derived_rollouts_by_id
    ):
        _reject(
            rejections,
            AnalysisInputRejectionCode.ROLLOUT_LOOKUP_MISMATCH,
            "Caller-supplied rollout facts differ from the validated A bundle.",
        )
    allowed_statuses = {
        "measured",
        "non_persistence",
        "generation_failure",
        "excluded",
    }
    seen: set[str] = set()
    seen_rollouts: set[str] = set()
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_VALUE,
                "Measurement row must be a mapping.",
                index,
            )
            continue
        required_row = (
            "measurement_id",
            "rollout_id",
            "rollout_run_id",
            "event_id",
            "direction_version",
            "control_type",
            "alpha_applied",
            "measurement_status",
            "displacement_blocks",
            "persistence_score",
            "ssim",
            "outcome_detail",
            "measurement_artifact_hash",
        )
        missing = [field for field in required_row if field not in row]
        if missing:
            _reject(
                rejections,
                AnalysisInputRejectionCode.MISSING_REQUIRED_FIELD,
                "Measurement row is missing: " + ", ".join(missing),
                index,
            )
            continue
        measurement_id = row["measurement_id"]
        if (
            not isinstance(measurement_id, str)
            or not measurement_id
            or measurement_id in seen
        ):
            _reject(
                rejections,
                AnalysisInputRejectionCode.DUPLICATE_IDENTITY,
                "measurement_id must be unique and non-empty.",
                index,
            )
        else:
            seen.add(measurement_id)
        rollout_id = row["rollout_id"]
        if isinstance(rollout_id, str):
            if rollout_id in seen_rollouts:
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.DUPLICATE_IDENTITY,
                    "Each rollout must have exactly one measurement row.",
                    index,
                )
            seen_rollouts.add(rollout_id)
        status = row["measurement_status"]
        if not isinstance(status, str) or status not in allowed_statuses:
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_LIFECYCLE,
                "Unknown measurement_status.",
                index,
            )
            continue
        for field in (
            "rollout_id",
            "rollout_run_id",
            "event_id",
            "direction_version",
            "control_type",
        ):
            if not isinstance(row[field], str) or not row[field]:
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.INVALID_IDENTITY,
                    f"{field} must be a non-empty string.",
                    index,
                )
        control_type = row["control_type"]
        if not isinstance(control_type, str) or control_type not in {
            "intervention",
            "alpha_zero",
            "random_direction",
        }:
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_VALUE,
                "Unknown control_type.",
                index,
            )
        if bundle_valid and isinstance(rollout_id, str):
            expected = derived_rollouts_by_id.get(rollout_id)
            if expected is None:
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.MANIFEST_MISMATCH,
                    "Measurement references a rollout outside the accepted manifest.",
                    index,
                )
            elif not isinstance(expected, Mapping):
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.MANIFEST_MISMATCH,
                    "Rollout registry entry must be a mapping.",
                    index,
                )
            else:
                expected_fields = (
                    "event_id",
                    "direction_version",
                    "control_type",
                    "alpha_applied",
                    "outcome",
                    "measurable",
                    "status",
                    "run_id",
                    "execution_status",
                )
                missing_expected = [
                    field for field in expected_fields if field not in expected
                ]
                if missing_expected:
                    _reject(
                        rejections,
                        AnalysisInputRejectionCode.MANIFEST_MISMATCH,
                        "Rollout registry entry is missing: "
                        + ", ".join(missing_expected),
                        index,
                    )
                    expected = {}
                compared_fields = (
                    ("event_id", "event_id"),
                    ("direction_version", "direction_version"),
                    ("control_type", "control_type"),
                    ("rollout_run_id", "run_id"),
                )
                for row_field, expected_field in compared_fields:
                    if row[row_field] != expected.get(expected_field):
                        _reject(
                            rejections,
                            AnalysisInputRejectionCode.MANIFEST_MISMATCH,
                            f"Measurement {row_field} differs from the A bundle.",
                            index,
                        )
                expected_alpha = expected.get("alpha_applied")
                if not _finite(expected_alpha):
                    _reject(
                        rejections,
                        AnalysisInputRejectionCode.MANIFEST_MISMATCH,
                        "Rollout registry alpha must be finite.",
                        index,
                    )
                outcome = expected.get("outcome")
                measurable = expected.get("measurable")
                lifecycle = expected.get("status")
                execution_status = expected.get("execution_status")
                expected_measurement_status: str | None = None
                lifecycle_is_coherent = False
                if outcome == "generation_failure":
                    lifecycle_is_coherent = (
                        measurable is False
                        and lifecycle == "excluded"
                        and execution_status in ("failed", "completed_with_failures")
                    )
                    expected_measurement_status = "generation_failure"
                elif lifecycle in ("excluded", "superseded"):
                    lifecycle_is_coherent = (
                        measurable is False
                        and execution_status in ("completed", "completed_with_failures")
                        and outcome in ("measurable_continuation", "non_persistence")
                    )
                    expected_measurement_status = "excluded"
                elif outcome == "measurable_continuation":
                    lifecycle_is_coherent = (
                        measurable is True
                        and lifecycle == "accepted"
                        and execution_status in ("completed", "completed_with_failures")
                    )
                    expected_measurement_status = "measured"
                elif outcome == "non_persistence":
                    lifecycle_is_coherent = (
                        measurable is False
                        and lifecycle == "accepted"
                        and execution_status in ("completed", "completed_with_failures")
                    )
                    expected_measurement_status = "non_persistence"

                if not lifecycle_is_coherent:
                    _reject(
                        rejections,
                        AnalysisInputRejectionCode.INVALID_LIFECYCLE,
                        (
                            "Rollout outcome, lifecycle, measurable flag, "
                            "and run status conflict."
                        ),
                        index,
                    )
                elif row["measurement_status"] != expected_measurement_status:
                    _reject(
                        rejections,
                        AnalysisInputRejectionCode.OUTCOME_CONFLATION,
                        (
                            "Measurement status contradicts the producing "
                            "rollout outcome."
                        ),
                        index,
                    )
                if (
                    _finite(expected_alpha)
                    and _finite(row["alpha_applied"])
                    and not math.isclose(
                        float(row["alpha_applied"]),
                        float(expected_alpha),
                        rel_tol=1e-10,
                        abs_tol=1e-12,
                    )
                ):
                    _reject(
                        rejections,
                        AnalysisInputRejectionCode.MANIFEST_MISMATCH,
                        "Measurement alpha differs from the rollout registry.",
                        index,
                    )
        if not _finite(row["alpha_applied"]):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_VALUE,
                "alpha_applied must be finite.",
                index,
            )
        if not is_hex_digest(row["measurement_artifact_hash"], 64):
            _reject(
                rejections,
                AnalysisInputRejectionCode.INVALID_HASH,
                "measurement_artifact_hash must be SHA-256.",
                index,
            )
        measurements = (
            row["displacement_blocks"],
            row["persistence_score"],
            row["ssim"],
        )
        if status == "measured":
            if not all(_finite(value) for value in measurements):
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.INVALID_VALUE,
                    (
                        "Measured rows require finite displacement, "
                        "persistence, and SSIM."
                    ),
                    index,
                )
            elif not (
                0.0 <= float(row["persistence_score"]) <= 1.0
                and 0.0 <= float(row["ssim"]) <= 1.0
            ):
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.INVALID_VALUE,
                    "Persistence and SSIM must lie in [0, 1].",
                    index,
                )
        else:
            if any(value is not None for value in measurements):
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.OUTCOME_CONFLATION,
                    (
                        "Unmeasured outcomes must not be encoded as zero "
                        "measurements."
                    ),
                    index,
                )
            if (
                not isinstance(row["outcome_detail"], str)
                or not row["outcome_detail"].strip()
            ):
                _reject(
                    rejections,
                    AnalysisInputRejectionCode.INVALID_VALUE,
                    "Unmeasured outcomes require outcome_detail.",
                    index,
                )
    if bundle_valid and seen_rollouts != set(derived_rollouts_by_id):
        _reject(
            rejections,
            AnalysisInputRejectionCode.MANIFEST_MISMATCH,
            "Measurement rows do not exactly cover the accepted rollout IDs.",
        )
    return AnalysisInputValidationResult(not rejections, tuple(rejections))
