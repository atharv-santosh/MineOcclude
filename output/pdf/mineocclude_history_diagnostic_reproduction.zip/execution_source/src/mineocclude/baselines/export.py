"""Package baseline predictions into B's frozen consumer contract.

Every baseline module in this package produces a list of
:class:`~mineocclude.baselines.interface.BaselineRow`. Before those rows
mean anything to Person B, they must be shaped into one
``person-b-baseline-input-v0.1`` document per (baseline, target) pair
and pass B's real validator, ``mineocclude.contracts.analysis_inputs
.validate_baseline_input`` -- not a paraphrase of it. This module is the
only place that shape conversion happens, so every baseline stays
honest about the same handoff format.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import replace

from mineocclude.analysis.manifests import is_hex_digest
from mineocclude.baselines.interface import BaselineRow, TargetName, TrajectoryContext
from mineocclude.baselines.production_fold_contract_v0_1 import (
    PRODUCTION_FOLD_CONTRACT_VERSION,
    PRODUCTION_FOLD_MANIFEST_FORMAT_VERSION,
    ProductionFoldContractError,
    validate_production_fold_document,
)
from mineocclude.contracts.analysis_inputs import (
    BASELINE_FAMILY_CONTRACTS,
    AnalysisInputValidationResult,
    validate_baseline_input,
)
from mineocclude.contracts.identity import SCHEMA_VERSION
from mineocclude.probes.splits import GroupedSplitError, validate_fold_manifest

BASELINE_INPUT_SCHEMA_VERSION = "person-b-baseline-input-v0.1"
PRODUCER_ROLE = "person_d"

FrameKey = tuple[str, int]


class BaselineExportError(ValueError):
    """Raised when a baseline document cannot be honestly constructed."""


def validate_b_fold_manifest(fold_manifest: Mapping[str, object]) -> None:
    """Validate B's fold manifest through the correct version-dispatched authority.

    Dispatches on the document's own ``fold_manifest_format_version``:
    absent (historical manifests never carried this field) routes to the
    pre-existing :func:`mineocclude.probes.splits.validate_fold_manifest`
    deterministic-reproduction check, completely unchanged. Exactly
    ``PRODUCTION_FOLD_MANIFEST_FORMAT_VERSION`` routes to Person B's
    ratified signed-explicit-mapping validator instead -- that
    reproduction check is provably wrong for this format (the real
    production manifest inherits its fold assignment from an original,
    pre-join, six-layout computation it never rebalances after five
    layouts were admitted with reduced row counts; see
    production_fold_contract_v0_1's module docstring). Any other,
    unrecognized format version fails closed rather than silently
    falling through to either validator.

    Shared by :func:`attach_b_fold_assignments` and the production CLI's
    preflight, so the producing path can never bypass this check.
    """

    format_version = (
        fold_manifest.get("fold_manifest_format_version")
        if isinstance(fold_manifest, Mapping)
        else None
    )
    if format_version == PRODUCTION_FOLD_MANIFEST_FORMAT_VERSION:
        try:
            validate_production_fold_document(
                fold_manifest, contract_version=PRODUCTION_FOLD_CONTRACT_VERSION
            )
        except ProductionFoldContractError as error:
            raise BaselineExportError(
                f"authoritative B production fold manifest is invalid: {error}"
            ) from error
    elif format_version is None:
        try:
            validate_fold_manifest(fold_manifest)
        except (GroupedSplitError, TypeError, ValueError) as error:
            raise BaselineExportError(
                f"authoritative B fold manifest is invalid: {error}"
            ) from error
    else:
        raise BaselineExportError(
            f"unknown fold_manifest_format_version: {format_version!r}"
        )


def attach_b_fold_assignments(
    contexts: Sequence[TrajectoryContext],
    *,
    fold_manifest: Mapping[str, object],
) -> list[TrajectoryContext]:
    """Attach exact frame memberships from B's sealed fold manifest.

    Person D never computes fold membership. The supplied artifact is
    first validated by :func:`validate_b_fold_manifest`, then required
    to cover exactly the submitted ``trajectory_id + model_frame_idx``
    identities.
    """

    validate_b_fold_manifest(fold_manifest)

    memberships = fold_manifest.get("memberships")
    if not isinstance(memberships, list):
        # B's validator currently guarantees this; retain a fail-closed
        # boundary if its implementation ever changes.
        raise BaselineExportError(
            "authoritative B fold manifest has no membership rows"
        )

    membership_by_key: dict[FrameKey, Mapping[str, object]] = {}
    for membership in memberships:
        if not isinstance(membership, Mapping):
            raise BaselineExportError("B fold membership must be a mapping")
        key = (
            membership.get("trajectory_id"),
            membership.get("model_frame_idx"),
        )
        if key in membership_by_key:
            raise BaselineExportError(
                f"duplicate authoritative fold membership for {key}"
            )
        membership_by_key[key] = membership

    requested_by_key: dict[FrameKey, TrajectoryContext] = {}
    for context in contexts:
        key = (context.trajectory_id, context.model_frame_idx)
        if key in requested_by_key:
            raise BaselineExportError(f"duplicate requested baseline row {key}")
        requested_by_key[key] = context

    requested_keys = set(requested_by_key)
    authoritative_keys = set(membership_by_key)
    if requested_keys != authoritative_keys:
        missing = sorted(requested_keys - authoritative_keys)
        unexpected = sorted(authoritative_keys - requested_keys)
        raise BaselineExportError(
            "D rows do not exactly match B fold-manifest coverage. "
            f"Missing: {missing}. Unexpected: {unexpected}."
        )

    annotated: list[TrajectoryContext] = []
    for context in contexts:
        key = (context.trajectory_id, context.model_frame_idx)
        membership = membership_by_key[key]
        if membership.get("layout_id") != context.layout_id:
            raise BaselineExportError(
                f"layout identity for {key} disagrees with B's fold manifest"
            )
        authoritative_fold = membership.get("fold_idx")
        if context.fold not in {-1, authoritative_fold}:
            raise BaselineExportError(
                f"existing fold for {key} conflicts with B's fold manifest"
            )
        annotated.append(replace(context, fold=authoritative_fold))
    return annotated


def build_baseline_document(
    rows: Sequence[BaselineRow],
    *,
    target_name: TargetName,
    baseline_id: str,
    baseline_family: str,
    config_hash: str,
    input_manifest_hash: str,
    fold_manifest_hash: str,
    fit_manifest_hash: str,
    fit_id_by_key: Mapping[FrameKey, str] | None = None,
    default_fit_id: str | None = None,
) -> dict[str, object]:
    """Build one ``person-b-baseline-input-v0.1`` document for one target.

    Only rows where ``target_name`` matches and ``applicable`` is true
    become prediction rows -- a baseline that cannot define a value for
    a frame omits that key rather than submitting a fabricated
    prediction (BaselineRow.__post_init__ already forbids a
    non-applicable row from carrying a numeric value). Whether the
    resulting key set exactly covers B's accepted/eligible frames is
    B's call, checked by passing ``expected_fold_by_frame`` to
    :func:`validate_document`; this function only shapes the document.
    """

    if fit_id_by_key is None and default_fit_id is None:
        raise BaselineExportError(
            "either fit_id_by_key or default_fit_id must be supplied"
        )

    family_contract = BASELINE_FAMILY_CONTRACTS.get(baseline_family)
    if family_contract is None:
        raise BaselineExportError(
            f"baseline_family {baseline_family!r} is not supported by "
            "Person B's authoritative baseline contract"
        )
    if target_name not in family_contract["target_names"]:
        raise BaselineExportError(
            f"target_name {target_name!r} is not allowed for "
            f"baseline_family {baseline_family!r}"
        )

    feature_access = sorted(family_contract["feature_access"])
    legal_information = dict(family_contract["legal_information"])

    for name, value in (
        ("config_hash", config_hash),
        ("input_manifest_hash", input_manifest_hash),
        ("fold_manifest_hash", fold_manifest_hash),
        ("fit_manifest_hash", fit_manifest_hash),
    ):
        if not is_hex_digest(value, 64):
            raise BaselineExportError(f"{name} must be a SHA-256 hex digest.")

    prediction_rows: list[dict[str, object]] = []
    seen_keys: set[FrameKey] = set()
    for row in rows:
        if row.target_name != target_name or not row.applicable:
            continue
        key = (row.trajectory_id, row.model_frame_idx)
        if key in seen_keys:
            raise BaselineExportError(f"duplicate baseline prediction for {key}")
        seen_keys.add(key)

        fit_id = (fit_id_by_key or {}).get(key, default_fit_id)
        if fit_id is None:
            raise BaselineExportError(f"no fit_id available for row {key}")

        prediction_rows.append(
            {
                "trajectory_id": row.trajectory_id,
                "model_frame_idx": row.model_frame_idx,
                "fold_idx": row.fold,
                "prediction": row.prediction,
                "prediction_scope": "out_of_fold",
                "fit_id": fit_id,
            }
        )

    if not prediction_rows:
        raise BaselineExportError(
            f"no applicable {target_name!r} rows for baseline {baseline_id!r}; "
            "an empty document cannot pass B's non-empty-rows requirement"
        )

    return {
        "schema_version": SCHEMA_VERSION,
        "baseline_input_schema_version": BASELINE_INPUT_SCHEMA_VERSION,
        "producer_role": PRODUCER_ROLE,
        "baseline_id": baseline_id,
        "baseline_family": baseline_family,
        "target_name": target_name,
        "feature_access": feature_access,
        "legal_information": legal_information,
        "config_hash": config_hash,
        "input_manifest_hash": input_manifest_hash,
        "fold_manifest_hash": fold_manifest_hash,
        "fit_manifest_hash": fit_manifest_hash,
        "rows": prediction_rows,
    }


def validate_document(
    document: Mapping[str, object],
    *,
    expected_fold_by_frame: Mapping[FrameKey, int] | None = None,
) -> AnalysisInputValidationResult:
    """Validate a baseline document against B's real consumer contract.

    Thin wrapper kept so every caller in this package validates through
    one place rather than re-importing B's contract module directly.
    """

    return validate_baseline_input(
        document, expected_fold_by_frame=expected_fold_by_frame
    )
