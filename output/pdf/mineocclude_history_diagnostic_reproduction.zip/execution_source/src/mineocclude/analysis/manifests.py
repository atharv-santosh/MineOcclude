"""Canonical hashing and provenance validation for Person B artifacts."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from mineocclude.contracts.identity import CODE_SHA_LENGTH, SHA256_LENGTH


ANALYSIS_ARTIFACT_SCHEMA_VERSION = "person-b-analysis-artifact-v0.1"
CANONICAL_FLOAT_DECIMAL_PLACES = 12


class AnalysisArtifactError(ValueError):
    """Raised when a B-owned artifact cannot be trusted or reproduced."""


def is_hex_digest(value: Any, length: int) -> bool:
    """Return whether *value* is exactly an ASCII hexadecimal digest."""

    return (
        isinstance(value, str)
        and len(value) == length
        and all(character in "0123456789abcdefABCDEF" for character in value)
    )


def canonicalize_evidence_numbers(value: Any) -> Any:
    """Return a copy with finite floats normalized for portable evidence.

    Probe fits can differ in the final machine bit across Python, NumPy, and
    BLAS builds. Twelve decimal places are far tighter than any frozen
    scientific tolerance while preventing those non-scientific differences
    from changing JSON evidence and every downstream SHA-256 reference.
    """

    if isinstance(value, bool) or value is None or isinstance(value, (str, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise AnalysisArtifactError(
                "Artifact floats must be finite before canonicalization."
            )
        normalized = round(value, CANONICAL_FLOAT_DECIMAL_PLACES)
        return 0.0 if normalized == 0.0 else normalized
    if isinstance(value, Mapping):
        return {
            key: canonicalize_evidence_numbers(item)
            for key, item in value.items()
        }
    if isinstance(value, Sequence) and not isinstance(
        value, (str, bytes, bytearray)
    ):
        normalized_items = [canonicalize_evidence_numbers(item) for item in value]
        return (
            tuple(normalized_items)
            if isinstance(value, tuple)
            else normalized_items
        )
    return value


def canonical_json_bytes(value: Any) -> bytes:
    """Serialize one artifact deterministically and reject non-finite floats."""

    try:
        return json.dumps(
            canonicalize_evidence_numbers(value),
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    except (TypeError, ValueError) as error:
        raise AnalysisArtifactError(
            f"Artifact is not canonical-JSON serializable: {error}"
        ) from error


def sha256_value(value: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def sha256_file(path: Path | str) -> str:
    """Hash literal file bytes; no parsing or normalization is performed."""

    try:
        payload = Path(path).read_bytes()
    except OSError as error:
        raise AnalysisArtifactError(f"Could not hash {path}: {error}") from error
    return hashlib.sha256(payload).hexdigest()


def seal_artifact(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Return a copied artifact carrying a hash over every other field."""

    if not isinstance(payload, Mapping):
        raise AnalysisArtifactError("Artifact payload must be a mapping.")
    sealed = canonicalize_evidence_numbers(dict(payload))
    if "artifact_hash" in sealed:
        raise AnalysisArtifactError(
            "artifact_hash is computed by seal_artifact and cannot be supplied."
        )
    sealed.setdefault("artifact_schema_version", ANALYSIS_ARTIFACT_SCHEMA_VERSION)
    _validate_base_fields(sealed)
    sealed["artifact_hash"] = sha256_value(sealed)
    return sealed


def _validate_base_fields(document: Mapping[str, Any]) -> None:
    required = (
        "artifact_schema_version",
        "artifact_type",
        "artifact_id",
        "code_sha",
        "config_hash",
        "input_manifest_hash",
    )
    missing = [field for field in required if field not in document]
    if missing:
        raise AnalysisArtifactError(
            "Missing artifact provenance fields: " + ", ".join(missing)
        )
    if document["artifact_schema_version"] != ANALYSIS_ARTIFACT_SCHEMA_VERSION:
        raise AnalysisArtifactError("Analysis artifact schema version mismatch.")
    for field in ("artifact_type", "artifact_id"):
        if not isinstance(document[field], str) or not document[field].strip():
            raise AnalysisArtifactError(f"{field} must be a non-empty string.")
    if not is_hex_digest(document["code_sha"], CODE_SHA_LENGTH):
        raise AnalysisArtifactError(
            "code_sha must be a 40-character hexadecimal code-provenance digest."
        )
    for field in ("config_hash", "input_manifest_hash"):
        if not is_hex_digest(document[field], SHA256_LENGTH):
            raise AnalysisArtifactError(f"{field} must be a SHA-256 digest.")


def validate_sealed_artifact(
    document: Mapping[str, Any],
    *,
    expected_type: str | None = None,
) -> None:
    """Validate base provenance and the canonical content hash."""

    if not isinstance(document, Mapping):
        raise AnalysisArtifactError("Artifact must be a mapping.")
    _validate_base_fields(document)
    if expected_type is not None and document["artifact_type"] != expected_type:
        raise AnalysisArtifactError(
            f"Expected artifact_type={expected_type!r}, "
            f"received {document['artifact_type']!r}."
        )
    artifact_hash = document.get("artifact_hash")
    if not is_hex_digest(artifact_hash, SHA256_LENGTH):
        raise AnalysisArtifactError("artifact_hash must be a SHA-256 digest.")
    unhashed = dict(document)
    del unhashed["artifact_hash"]
    if sha256_value(unhashed) != artifact_hash:
        raise AnalysisArtifactError("artifact_hash does not match artifact contents.")


def build_event_manifest(
    manifest_id: str,
    event_ids: list[str] | tuple[str, ...],
) -> dict[str, Any]:
    """Build the compact fit/validation event manifest required by B-to-A."""

    if not isinstance(manifest_id, str) or not manifest_id.strip():
        raise AnalysisArtifactError("manifest_id must be non-empty.")
    if (
        not isinstance(event_ids, (list, tuple))
        or not event_ids
        or any(not isinstance(value, str) or not value for value in event_ids)
        or len(set(event_ids)) != len(event_ids)
    ):
        raise AnalysisArtifactError("event_ids must be unique non-empty strings.")
    ordered = sorted(event_ids)
    body = {"manifest_id": manifest_id, "event_ids": ordered}
    return {**body, "manifest_hash": sha256_value(body)}


def validate_event_manifest(manifest: Mapping[str, Any]) -> None:
    if not isinstance(manifest, Mapping):
        raise AnalysisArtifactError("Event manifest must be a mapping.")
    required = ("manifest_id", "manifest_hash", "event_ids")
    missing = [field for field in required if field not in manifest]
    if missing:
        raise AnalysisArtifactError(
            "Event manifest is missing: " + ", ".join(missing)
        )
    rebuilt = build_event_manifest(manifest["manifest_id"], manifest["event_ids"])
    if manifest["manifest_hash"] != rebuilt["manifest_hash"]:
        raise AnalysisArtifactError(
            "Event manifest hash does not match its ID and event identities."
        )


def require_disjoint_event_sets(
    fit_manifest: Mapping[str, Any],
    validation_manifest: Mapping[str, Any],
    heldout_events: list[Mapping[str, Any]] | tuple[Mapping[str, Any], ...],
) -> None:
    """Reject fit/validation/held-out overlap before request construction."""

    validate_event_manifest(fit_manifest)
    validate_event_manifest(validation_manifest)
    fit_ids = set(fit_manifest.get("event_ids", []))
    validation_ids = set(validation_manifest.get("event_ids", []))
    if not isinstance(heldout_events, (list, tuple)) or not heldout_events:
        raise AnalysisArtifactError("Held-out events must be a non-empty sequence.")
    heldout_ids: set[str] = set()
    for event in heldout_events:
        if not isinstance(event, Mapping):
            raise AnalysisArtifactError("Held-out event records must be mappings.")
        event_id = event.get("event_id")
        if not isinstance(event_id, str) or not event_id:
            raise AnalysisArtifactError("Held-out events require non-empty event_id.")
        if event_id in heldout_ids:
            raise AnalysisArtifactError("Held-out event IDs must be unique.")
        heldout_ids.add(event_id)
    if fit_ids & validation_ids or fit_ids & heldout_ids or validation_ids & heldout_ids:
        raise AnalysisArtifactError(
            "Fit, validation, and held-out event identities must be disjoint."
        )
